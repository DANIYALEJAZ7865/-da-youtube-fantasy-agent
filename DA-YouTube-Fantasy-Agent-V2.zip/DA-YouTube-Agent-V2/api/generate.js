export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  if (req.method === "OPTIONS") return res.status(204).end();
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST." });

  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(500).json({ error: "OPENAI_API_KEY is missing in Vercel Environment Variables." });

  try {
    const { action, seriesTitle, world, hero, premise, episodeNumber, previousSummary, topic, format } = req.body || {};
    if (!action) return res.status(400).json({ error: "Missing action." });

    const base = `You are DA Fantasy Animation Producer, an expert original fantasy-series showrunner.
Create original stories. Do not copy existing anime, films, novels, copyrighted characters, scripts, or signature designs.
Keep continuity consistent with the supplied series bible. Make visual directions concrete enough for an image/video generation tool.
Avoid graphic gore, sexual content involving minors, and hateful content.`;
    let task = "";
    if (action === "episode") {
      if (!seriesTitle || !hero || !premise || !topic) return res.status(400).json({error:"Please fill series title, hero, premise and episode topic."});
      task = `${base}
SERIES BIBLE
Series: ${seriesTitle}
World: ${world || "A high-fantasy world of kingdoms, ancient ruins and dragons"}
Hero: ${hero}
Core premise: ${premise}
Episode number: ${episodeNumber || 1}
Previous episode summary: ${previousSummary || "This is the opening episode."}
New episode topic: ${topic}
Format: ${format || "8-12 minute episode"}

Return ONLY valid JSON:
{
 "episode_title":"...",
 "logline":"one sentence",
 "continuity_notes":["..."],
 "youtube_title":"...",
 "description":"...",
 "hashtags":["#..."],
 "thumbnail_prompt":"...",
 "characters":[{"name":"...","visual_identity":"...","voice_direction":"..."}],
 "script":"complete narration and dialogue with speaker labels",
 "scenes":[
  {"scene_number":1,"duration_seconds":45,"location":"...","visual_prompt":"original detailed cinematic visual prompt; include character appearance consistency, framing, lighting, motion and aspect ratio 16:9","action":"what happens","dialogue":"spoken dialogue or narration","sound_design":"music mood and sound effects"}
 ],
 "next_episode_hook":"...",
 "pinned_comment":"...",
 "review_checklist":["Check character consistency","Check generated visuals and audio rights"]
}
Create 8-12 scenes for a long episode, or 4-6 for a short. Aim for a coherent beginning, escalation, climax and ending hook. No fake claims about actual trends or performance.`;
    } else if (action === "ideas") {
      task = `${base}
For this series: ${seriesTitle || "Original fantasy adventure"}. Hero: ${hero || "A young dragon-bonded hero"}. Premise: ${premise || "A hidden power awakens"}.
Return ONLY valid JSON: {"ideas":[{"topic":"...","hook":"...","format":"Long episode or Short","why_it_works":"story reason, not a claim about live trends"}]}. Give 10 varied, connected episode/Short ideas.`;
    } else {
      return res.status(400).json({error:"Unknown action."});
    }

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {"Authorization": `Bearer ${key}`, "Content-Type":"application/json"},
      body: JSON.stringify({model: process.env.OPENAI_MODEL || "gpt-5", input: task})
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({error:data.error?.message || "AI request failed."});
    const output = (data.output || []).flatMap(x=>x.content || [])
      .filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
    if (!output) return res.status(502).json({error:"Empty AI response. Try again."});
    const cleaned = output.replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/,"").trim();
    try { return res.status(200).json(JSON.parse(cleaned)); }
    catch { return res.status(502).json({error:"AI returned invalid JSON. Please retry."}); }
  } catch (e) {
    return res.status(500).json({error:e.message || "Unexpected server error."});
  }
}