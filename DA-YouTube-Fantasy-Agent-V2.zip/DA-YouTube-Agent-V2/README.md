# DA YouTube Fantasy Animation Agent — Build 2

A separate Vercel project for creating original fantasy animation episode packages.

## Included
- Fantasy series bible fields: series, world, hero, premise and previous-episode summary.
- AI episode writer with dialogue, narration, continuity notes, 8–12 scene prompts for long episodes, thumbnail prompt, YouTube metadata and next-episode hook.
- Ten story-idea generator.
- Editable scene prompts and scripts.
- Draft / approved review status.
- Episode library stored in the current browser's local storage.
- JSON export and a basic storyboard-style WebM renderer.

## Honest capability boundary
This is a working script/storyboard production agent, not a complete generative animation studio yet. The included video renderer creates a simple text-and-gradient storyboard video. It does not generate character artwork, animated footage, AI voices, background music, or YouTube uploads. Those require connecting separate media APIs and YouTube OAuth. The approval button only records your review decision locally; it never publishes.

## Deploy from Android without touching your existing site
1. Download and extract the ZIP.
2. Create a **new private GitHub repository** named `da-youtube-fantasy-agent`.
3. Upload `index.html`, `package.json`, `vercel.json`, `README.md`, and the `api` folder containing `generate.js`.
4. In Vercel, choose Add New → Project → Import the new repository.
5. Deploy.
6. In Vercel Project → Settings → Environment Variables, add:
   - `OPENAI_API_KEY` = your secret OpenAI API key
   - Optional `OPENAI_MODEL` = a model enabled for your API account (default is `gpt-5`)
7. Redeploy after saving environment variables.
8. Open the deployment URL in Chrome on Android.

## API key safety
Never put the key in HTML, client JavaScript, GitHub, screenshots or messages. Keep it only in Vercel environment variables. Revoke any key that becomes exposed.

## Daily production routine
1. Generate the next episode or Short.
2. Read and edit the script and each scene prompt.
3. Generate artwork/clips/voice using your chosen media tools (not included in this starter).
4. Assemble the final video in a video editor.
5. Watch the complete export and check music, visual and voice rights.
6. Mark approved only after review. Upload manually to YouTube for now.

## Next technical upgrades
- Add image-generation API for consistent character reference sheets and scene stills.
- Add a video-generation provider to turn scene prompts into clips.
- Add voice generation and subtitle timing.
- Add FFmpeg/cloud rendering for final MP4 with audio.
- Add YouTube OAuth, channel selection, upload, privacy setting and a final explicit publish confirmation.
